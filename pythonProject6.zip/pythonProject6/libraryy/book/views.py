from django.shortcuts import render, redirect
from .models import Book
from .forms import BookForm
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout

def book_list(request):
    books = Book.objects.all()
    return render(request, 'book_list.html', {'books': books})

def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm()
    return render(request, 'library/add_book.html', {'form': form})



def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('book_list')
    else:
        form = UserCreationForm()
    return render(request, 'library/register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('book_list')
    else:
        form = AuthenticationForm()
    return render(request, 'library/login.html', {'form': form})

def search_books(request):
    query = request.GET.get('q')
    if query:
        books = Book.objects.filter(query(title__icontains=query) | query(author__icontains=query))
    else:
        books = Book.objects.all()
    return render(request, 'library/search_books.html', {'books': books, 'query': query})

def reserve_book(request, book_id):
    book = Book.object.get(Book, pk=book_id)
    if not book.is_reserved:
        book.is_reserved = True

        book.save()
    return redirect('book_list')



def index(requset):
    return  render(requset,"index.html")

