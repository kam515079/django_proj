from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
class Book(models.Model):
    name_book=models.CharField(max_length=100)
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=50)
    publication_date = models.DateField()
    is_reserved = models.BooleanField(default=False)
    def __str__(self):
        return self.title



